## Setting up for Development

Clone the repository. Instead of copying the files into a `ghidra_scripts` directory, you can choose to add a new script directory from the Script Manager window ( in the top right ). Add this directory as a scripts directory using the GUI.
